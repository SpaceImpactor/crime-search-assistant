<?php
session_start();

if(!$_SESSION['login_user'])
{

    header("Location: login.php");
}
	
    $con=mysqli_connect("localhost","root","");
	mysqli_select_db($con,"users");
	
	if(isset($_GET["id=='1'"])){
	
	$result_query = "select * from criminals where id= '1' ";
	
	$run_result = mysqli_query($con,$result_query);
	
	if(mysqli_num_rows($run_result)>0){

	
	$row_result=mysqli_fetch_array($run_result)
		
		$criminal=$row_result['criminal'];
		$link=$row_result['link'];	
         
    
    }
    
}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <title>Criminal</title>
</head>
<style>
    .r {
        margin-top: 50px;

</style>

<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.html">Crime Search Assistant</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="res.php"><span class="glyphicon glyphicon-search"></span> MORE</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;<?php echo strtoupper($_SESSION['login_user']); ?></a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> LOGOUT</a></li>
    </ul>
  </div>
</nav>

<div class="container">
    <div class="r">
        <div class="col-md-3 col-md-offset-5 ">
            
            <h1><?php echo "$criminal"; ?></h1>
        </div> 
    </div><br></div>
    
    <div class="container">
        <br><br>
        <div class="row">
            <div class="col-md-3 ">
                <img src='images/criminal.jpg' width='150' height='150'></div>
           
           <p align='justify'><font size='4'><br>100 Kgs Gold theft has taken place today at the world convention hall in Harayana.Haryana Police said on Saturday it has arrested three people for an armed bank robbery in Gurugram and recovered about 30 kg stolen gold, firearms and ammunition from them.

A police spokesman said that some unidentified persons carrying firearms stole gold weighing 33 kg and Rs. 7.80 lakh in cash from Manappuram Finance Bank on New Railway Road, Gurugram on February 9.<br><br>

They also injured employees and customers of the bank.

A case was registered under Sections 395 and 397 of the Indian Penal Code and Sections 25, 54 and 59 of the Arms Act at Civil Lines police station in Gurugram.The men came in a black SUV and fled after robbing the gold valuables and cash. <br><br>The gang leader and the SUV is under discrete surveillance of a strong police team and it has also been found that the offenders also used one bike while committing the crime. 

"While the Special Investigation Team (SIT) arrested three accused, namely Hoshiar Singh, Vikas Gupta and Bijender from Sector 29, Gurugram, another accused, Devender, was arrested from Ahmedabad," the spokesman said.<br><br>
               "At least 829 pouches of gold and some loose pouches, weighing about 30 kg, were recovered from their possession. Police also recovered two pistols and four rounds of ammunition from them," he added.
</font></p> 
            
            
            
        </div>
                </div>
            


</body>

</html>