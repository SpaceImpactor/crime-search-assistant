<?php
session_start();

if(!$_SESSION['login_user'])
{

    header("Location: login.php");
}

?>
<html>
<head>
<title>Result Page </title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    <style>
    .form {
        margin-top: 100px;}
        .col{
            margin-top:-600px;
        }
       
</style>

</head>
<body>
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.html">Crime Search Assistant</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;<?php echo strtoupper($_SESSION['login_user']); ?></a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> LOGOUT</a></li>
    </ul>
  </div>
</nav>
    <div class="container-fluid">
    <div class="col-md-">
            <div id="map" style="width:100%;height:90%">

<script type="text/javascript">
function myMap() {
  var mapCanvas = document.getElementById("map");
  var myCenter = new google.maps.LatLng(16.2334553,80.5486948); 
  var mapOptions = {center: myCenter, zoom: 4};
  var map = new google.maps.Map(mapCanvas,mapOptions);
  var marker = new google.maps.Marker({
    position: myCenter,
    animation: google.maps.Animation.BOUNCE
  });
  marker.setMap(map);
}
</script>

        <script  type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCSOJ3Y-nU2yRLF45gciH4bMTNmC4aQ89Q&callback=myMap"></script></div>
        </div></div>
    
    <div class="container">
    <div class="col">
        <div class="col-md-6 col-md-offset-3">
            
                    <form class="form" method="get" action="res.php">
                            <div class="input-group input-group-lg"  >
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input class="form-control" placeholder="Crime" name="crime" type="text" autofocus>
                            </div>
                            <br>
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                <input class="form-control" placeholder="Location" name="location" type="text">
                            </div><br>
                        </div>
            <div class="col-md-2 col-md-offset-7">
                <input class="btn btn-lg btn-danger btn-block" type="submit" value="FIND" name="submited"></div>
                    
                    </form>
        
        
        </div>
    </div>
    </div>
</body>
</html>