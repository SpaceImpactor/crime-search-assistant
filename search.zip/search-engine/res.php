<?php
session_start();

if(!$_SESSION['login_user'])
{

    header("Location: login.php");
}

?>
<html>
<head>
<title>Result Page </title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>h2{ margin-top:75px;}
    </style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.html">Crime Search Assistant</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
        <li><a href="welcome.php"><span class="glyphicon glyphicon-search"></span> FIND</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;<?php echo strtoupper($_SESSION['login_user']); ?></a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> LOGOUT</a></li>
    </ul>
  </div>
</nav>
<div class="container">
       <div class='col-md-offset-4'>
     <h2>&nbsp;ARRESTED CRIMINALS</h2>
           
     </div>
    </div>
</body>

</html>

<?php 
	
    $con=mysqli_connect("localhost","root","");
	mysqli_select_db($con,"users");
	
	if(isset($_GET['submited'])){
	
	$crime = $_GET['crime'];
    $location = $_GET['location'];
	
	
	$result_query = "select * from criminals where crime='$crime' and location='$location' and type='arrested' ";
	
	$run_result = mysqli_query($con,$result_query);
        
        if(mysqli_num_rows($run_result)==0)
        {
            echo "<div class='container'>
            <h4 style='color:red'><br><br>Please enter like this : gold, murder, cyber.... <br><br>NOTE: We didn't extend our services
            to many locations as well, try at max your surrounding cities. THANK YOU :)</h4></div>";
        }
	
	if(mysqli_num_rows($run_result)>0){

	
	while($row_result=mysqli_fetch_array($run_result)){
		
		$criminal=$row_result['criminal'];
		$link=$row_result['link'];	
        
     echo " <div class='container'>
      <a href='$link'><font size='6'>$criminal</font></a>
           </div> <br>"; 

		}
    
    }
}
?><br>
<div class="container">
       <div class='col-md-offset-4'>
     <h2>&nbsp;&nbsp;&nbsp;LOOSE CRIMINALS</h2>
     </div>
    </div><br><br>
<?php 
	
    $con=mysqli_connect("localhost","root","");
	mysqli_select_db($con,"users");
	
	if(isset($_GET['submited'])){
	
	$crime = $_GET['crime'];
    $location = $_GET['location'];
	
	
	$result_query = "select * from criminals where crime='$crime' and location='$location' and type='free' ";
	
	$run_result = mysqli_query($con,$result_query);
	
	if(mysqli_num_rows($run_result)>0){

	
	while($row_result=mysqli_fetch_array($run_result)){
		
		$criminal=$row_result['criminal'];
		$link=$row_result['link'];	
        
     echo " <div class='container'>
      <a href='$link'><font size='6'>$criminal</font></a>
           </div> <br>"; 

		}
    
    }
        if(($crime==' ') || ($location==''))
        {
           echo "<script>alert('Enter The Details to Proceed!')</script>"; 
        }
}
?>












