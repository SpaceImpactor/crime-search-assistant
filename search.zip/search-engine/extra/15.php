<?php
include("login/database/db_conection.php");

if(isset($_POST['login']))
{
    $user_email=$_POST['email'];
    $user_pass=$_POST['pass'];

    $check_user="select * from users WHERE user_email='$user_email'AND user_pass='$user_pass'";

    $run=mysqli_query($dbcon,$check_user);

    if(mysqli_num_rows($run))
    {
        header("location: search.html");

    }
    else
    {
        echo "<script>alert('Email or password is incorrect!')</script>";
    }
}
?>