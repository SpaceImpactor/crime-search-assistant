
<html>
<head lang="en">
    <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Registration</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;

</style>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.html">Crime Search Engine</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> LOGIN</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> REGISTER</a></li>
    </ul>
  </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-7 col-md-offset-3">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Registration</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="page2.php">
                        <fieldset>
                            <div class="input-group input-group-lg">
<span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span>                                <input class="form-control" placeholder="Police ID" name="name" type="text" autofocus>
                            </div><br>

                            <div class="input-group input-group-lg">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                            </div><br>
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">
                            </div><br>


                            <input class="btn btn-lg btn-success btn-block" type="submit" value="Register" name="register" >

                        </fieldset>
                    </form>
                    <center><b>Already registered ?</b> <br></b><a href="login.php">Login here</a></center>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>

<?php

include("database/db_conection.php");
if(isset($_POST['register']))
{
    $user_name=$_POST['name'];
    $user_pass=$_POST['pass'];
    $user_email=$_POST['email'];


    if($user_name=='')
    {
        
        echo"<script>alert('Please enter Your ID')</script>";
exit();
    }

    if($user_pass=='')
    {
        echo"<script>alert('Please enter the password')</script>";
exit();
    }

    if($user_email=='')
    {
        echo"<script>alert('Please enter the email')</script>";
    exit();
    }
    
    $check_email_query="select * from users WHERE user_email='$user_email'";
    $run_query=mysqli_query($dbcon,$check_email_query);
    $check_police_id="select * from officers where pid='$user_name'";
    $test_query=mysqli_query($dbcon,$check_police_id);
    
    if(mysqli_num_rows($test_query)>0)
    {
     $insert_user="insert into users (user_name,user_pass,user_email) VALUE ('$user_name','$user_pass','$user_email')";
    if(mysqli_query($dbcon,$insert_user))
    {
        echo"<script>window.open('welcome.php','_self')</script>";
    }
    }
    else if(mysqli_num_rows($run_query)>0)
    {
        echo "<script>alert('You have already Registered!')</script>";
exit();
    }
    else {
    echo "<script>alert('Sorry $user_name ,You are not an Authorised Police Officer')</script>";
exit();
    }
    

}

?>