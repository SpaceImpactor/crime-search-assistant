<html> 
    <head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
	<title>Result page</title> 
		
<style type="text/css">
.results { margin-left:12%; margin-right:12%; margin-top:10px;}
    .space{
	margin-top:20px;

}
</style>
        <link rel="stylesheet" type="text/css" href="style.css">
	</head> 
	
<body bgcolor="#F5DEB3"> 
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.html">Crime Search Assistant</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> LOGIN</a></li>
      <li><a href="registration.php"><span class="glyphicon glyphicon-user"></span> REGISTER</a></li>
    </ul>

  </div>
</nav>
    
    <div class="container-fluid">
  <form action="result.php" method="get">
	  <div class="space">
	  </div>
  <div class="form-group row">
    <div class="col-md-9 col-md-offset-1">
   <div class="input-group">
       	
       <input type="text" class="form-control" placeholder="Enter.." name="user_query">
     <div class="input-group-btn">
     <input type="submit" class="btn btn-danger" name="search" value="Search">
     </button>
  </div>
   </div>
      </div></div></div>
    <br><br>
        </form>
	
<?php 
	
    $con=mysqli_connect("localhost","root","");
	mysqli_select_db($con,"search");
	
	if(isset($_GET['search'])){
	
	$get_value = $_GET['user_query'];
	
	if($get_value==''){
	
	echo "<center><b>Please Write something in the search box!</b></center>";
	exit();
	}
	
	$result_query = "select * from sites where site_keywords like '%$get_value%' ";
	
	$run_result = mysqli_query($con,$result_query);
	
	if(mysqli_num_rows($run_result)<1){
	
	echo "<center><b>Oops! sorry, nothing was found in the database! and we'll make sure to update soon :) </b></center>";
	exit();
	
	}
	
	while($row_result=mysqli_fetch_array($run_result)){
		
		$site_title=$row_result['site_title'];
		$site_link=$row_result['site_link'];
		$site_desc=$row_result['site_desc'];
		$site_image=$row_result['site_image'];
	
	/** echo "<div class='results'>
		
		<h2>$site_title</h2>
		<a href='$site_link' target='_blank'>$site_link</a>
		<p align='justify'>$site_desc</p> 
		<img src='images/$site_image' width='100' height='100' />
		
		</div>"; **/
        
        
     echo " <div class='container'>
      <a href='$site_link'><font size='6'>$site_title</font></a>
             <div class='media'>
             <div class='media-left'>
             <a href='$site_link'><img src='images/$site_image' class='media-object' width='100' height='100'></a></div>
           <div class='media-body'>
           <p align='justify'><font size='4'>$site_desc</font></p> 
            </div>
           </div>
           </div> <br><br>"; 

		}
}


?>


</body> 
</html>