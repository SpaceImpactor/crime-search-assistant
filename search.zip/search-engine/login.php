
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <title>Login</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;

</style>

<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.html">Crime Search Assistant</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> LOGIN</a></li>
      <li><a href="registration.php"><span class="glyphicon glyphicon-user"></span> REGISTER</a></li>
    </ul>
  </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-7 col-md-offset-3">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Sign In</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="login.php">
                        <fieldset>
                            <div class="input-group input-group-lg"  >
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                            </div>
                            <br>
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">
                            </div><br>
    <!div class="g-recaptcha" data-sitekey="6Le8C0YUAAAAAGXuraXZS76cLZ4wSrRdJDNBUCme"><!/div>


                                <input class="btn btn-lg btn-success btn-block" type="submit" value="Login" name="login" >

                        
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

</html>

<?php
include("config.php");
   session_start();
include("database/db_conection.php");

if(isset($_POST['login']))
{   
   // $user=$_POST['name'];
    $user_email=$_POST['email'];
    $user_pass=$_POST['pass'];

    $check_user="select * from users WHERE user_email='$user_email'AND user_pass='$user_pass'";

    $run=mysqli_query($dbcon,$check_user);
    
   /* if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
        if(!$captcha){
          echo '<h2>Please check the the captcha form.</h2>';
          exit;
        }
        $secretKey = "6Le8C0YUAAAAAMUKnTRuVjUyZfnIiOv7HgPJhaTX";
        $ip = $_SERVER['REMOTE_ADDR'];
        $response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip);
        $responseKeys = json_decode($response,true);
        if(intval($responseKeys["success"]) !== 1) {
          echo '<h2>You are spammer ! Get the @$%K out</h2>';
        } else {
          echo '<h2>Thanks for posting comment.</h2>';
        } */

    if(mysqli_num_rows($run))
    { 
        $user="select * from users WHERE user_email='$user_email'AND user_pass='$user_pass'";
        $user_run=mysqli_query($dbcon,$user);
        $user_row=mysqli_fetch_array($user_run);
        $usr=$user_row['user_name'];
        $_SESSION['login_user']=$usr;

        echo "<script>window.open('welcome.php','_self')</script>";

        

    }
    else
    {
        echo "<script>alert('Email or password is incorrect!')</script>";
    }
}
?>